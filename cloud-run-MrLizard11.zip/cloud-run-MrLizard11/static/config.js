/**
 * Update this file with your Firebase configuration settings.
 * API key and auth domain are required.
 */

/**
 * ++++ ADD YOUR FIREBASE CONFIGURATION BELOW ++++
 * === Firebase Apikey and Domain ===
 * client_id 483645036888-87caun4k7urvbdgh9fq76n2dega4s513.apps.googleusercontent.com
 * Client secret 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
 *   projectId: "cloud-run-454522",
  storageBucket: "cloud-run-454522.firebasestorage.app",
  messagingSenderId: "945863103277",
  appId: "1:945863103277:web:604a788e0da7e216d839a4"
 */

/**
 * Firebase configuration
 * @type {{apiKey: string, authDomain: string}}
 */
const config = {
  apiKey: "AIzaSyCgrOaQtOivzFFPq2bnB2gGZRvExBiyMcE",
  authDomain: "cloud-run-454522.firebaseapp.com",
};